import { useState } from 'react';
import { useLocation, Navigate, Link } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { findPaths, categories } from '../data/mockData';
import PathCard from '../components/PathCard';
import IntroRequestModal from '../components/IntroRequestModal';

export default function Paths() {
  const location = useLocation();
  const { currentUser } = useUser();
  const [selectedPath, setSelectedPath] = useState(null);
  const [showModal, setShowModal] = useState(false);

  if (!location.state?.category) return <Navigate to="/" replace />;

  const { category, description } = location.state;
  const categoryInfo = categories.find(c => c.id === category);
  const paths = findPaths(currentUser.id, category);

  const handleRequestIntro = (path) => {
    setSelectedPath(path);
    setShowModal(true);
  };

  return (
    <div>
      <Link to="/" className="back-link">← Change search</Link>
      <h1 className="page-title">
        Paths for: {categoryInfo?.icon} {categoryInfo?.label}
      </h1>
      {description && (
        <p className="page-subtitle">"{description}"</p>
      )}

      {paths.length > 0 ? (
        <div>
          {paths.map((path, index) => (
            <PathCard
              key={index}
              currentUser={currentUser}
              connector={path.connector}
              target={path.target}
              onRequestIntro={() => handleRequestIntro(path)}
            />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="empty-icon" style={{ fontSize: 26 }}>🔍</div>
          <h2>No paths found</h2>
          <p>No paths found for this category right now. Try a different category or check back later as your network grows.</p>
          <Link to="/" className="btn-primary" style={{ display: 'inline-flex' }}>Try another search</Link>
        </div>
      )}

      {showModal && selectedPath && (
        <IntroRequestModal
          currentUser={currentUser}
          connector={selectedPath.connector}
          target={selectedPath.target}
          intent={{ category, description }}
          onClose={() => { setShowModal(false); setSelectedPath(null); }}
        />
      )}
    </div>
  );
}
