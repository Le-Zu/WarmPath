import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { getRequestsByRequester, getUserById } from '../data/mockData';

export default function MyRequests() {
  const { currentUser } = useUser();
  const [filter, setFilter] = useState('all');
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    setRequests(getRequestsByRequester(currentUser.id));
  }, [currentUser.id]);

  const filteredRequests = requests.filter(r => filter === 'all' || r.status === filter);

  const getStatusPill = (status) => {
    switch (status) {
      case 'pending':  return <span className="pill pill-pending">⏳ Pending</span>;
      case 'approved': return <span className="pill pill-approved">✓ Approved</span>;
      case 'declined': return <span className="pill pill-declined">Not approved</span>;
      default: return null;
    }
  };

  const formatDate = (timestamp) => {
    const diff = Date.now() - new Date(timestamp);
    const days = Math.floor(diff / 86400000);
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    return new Date(timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const filterTabs = [
    { id: 'all',      label: 'All',      count: requests.length },
    { id: 'pending',  label: 'Pending',  count: requests.filter(r => r.status === 'pending').length },
    { id: 'approved', label: 'Approved', count: requests.filter(r => r.status === 'approved').length },
    { id: 'declined', label: 'Declined', count: requests.filter(r => r.status === 'declined').length },
  ];

  if (requests.length === 0) {
    return (
      <div>
        <h1 className="page-title">My Intro Requests</h1>
        <div className="empty-state">
          <div className="empty-icon">
            <svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
            </svg>
          </div>
          <h2>No intro requests yet</h2>
          <p>When you request introductions through your network, they'll appear here.</p>
          <Link to="/" className="btn-primary" style={{ display: 'inline-flex' }}>Find Paths</Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="page-title">My Intro Requests</h1>
      <p className="page-subtitle">Track the status of introductions you've requested.</p>

      <div className="tab-row">
        {filterTabs.map(tab => (
          <button
            key={tab.id}
            className={`tab-btn ${filter === tab.id ? 'active' : ''}`}
            onClick={() => setFilter(tab.id)}
          >
            {tab.label}
            {tab.count > 0 && <span className="tab-count">{tab.count}</span>}
          </button>
        ))}
      </div>

      {filteredRequests.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '32px', color: 'var(--mid-gray)', fontSize: 14 }}>
          No {filter} requests
        </div>
      ) : (
        filteredRequests.map(request => {
          const connector = getUserById(request.connectorId);
          const target = getUserById(request.targetId);

          return (
            <div key={request.id} className="card">
              <div className="mini-path">
                <div className="mini-node">
                  <div className="avatar avatar-you avatar-sm">You</div>
                  <div className="mini-name">You</div>
                </div>
                <div className="mini-arrow">→</div>
                <div className="mini-node">
                  <div className="avatar avatar-conn avatar-sm">
                    {connector.name.split(' ')[0][0]}{connector.name.split(' ').pop()[0]}
                  </div>
                  <div className="mini-name">{connector.name.split(' ')[0]}</div>
                </div>
                <div className="mini-arrow">→</div>
                <div className="mini-node">
                  <div className="avatar avatar-target avatar-sm">
                    {target.name.split(' ')[0][0]}{target.name.split(' ').pop()[0]}
                  </div>
                  <div className="mini-name">{target.name.split(' ')[0]}</div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  {getStatusPill(request.status)}
                  <span style={{ fontSize: 12, color: 'var(--mid-gray)' }}>
                    {formatDate(request.updatedAt || request.createdAt)}
                  </span>
                </div>
              </div>

              <div className="message-box" style={{ marginBottom: 0, fontSize: 13 }}>
                {request.message}
              </div>

              <div className="req-card-footer">
                {request.status === 'approved' && (
                  <Link to={`/intro/${request.id}`} className="btn-primary" style={{ padding: '8px 18px', fontSize: 13 }}>
                    View Introduction →
                  </Link>
                )}
                {request.status === 'pending' && (
                  <span style={{ fontSize: 13, color: 'var(--mid-gray)' }}>
                    Waiting for {connector.name.split(' ')[0]} to respond…
                  </span>
                )}
                {request.status === 'declined' && (
                  <span style={{ fontSize: 13, color: 'var(--mid-gray)' }}>
                    This intro wasn't approved. <Link to="/" style={{ color: 'var(--terracotta)' }}>Try another path?</Link>
                  </span>
                )}
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}
