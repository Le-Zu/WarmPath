import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { categories } from '../data/mockData';
import ConnectorPrompt from '../components/ConnectorPrompt';

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [description, setDescription] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedCategory) return;
    navigate('/paths', { state: { category: selectedCategory, description: description.trim() } });
  };

  return (
    <div className="page-container">
      <ConnectorPrompt />

      <div className="home-header">
        <h1>What are you looking for<br />help with right now?</h1>
        <p>Select a category and we'll show you paths to people who can help.</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="category-grid">
          {categories.map(cat => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id)}
              className={`category-btn ${selectedCategory === cat.id ? 'selected' : ''}`}
            >
              <span className="cat-icon">{cat.icon}</span>
              <span className="cat-label">{cat.label}</span>
            </button>
          ))}
        </div>

        {selectedCategory && (
          <div style={{ marginBottom: 24 }}>
            <label className="form-label">Tell us more (optional)</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g., Looking for advice on consulting recruiting, specifically for sophomore internships..."
              rows={3}
            />
          </div>
        )}

        <button type="submit" className="btn-primary full-width" disabled={!selectedCategory}>
          Find paths →
        </button>
      </form>
    </div>
  );
}
