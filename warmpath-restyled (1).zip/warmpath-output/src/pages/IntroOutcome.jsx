import { useParams, Link, Navigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { introRequests, getUserById, generateContextPreRead } from '../data/mockData';
import ContactExchange from '../components/ContactExchange';

export default function IntroOutcome() {
  const { id } = useParams();
  const { currentUser } = useUser();
  const request = introRequests.find(r => r.id === parseInt(id));

  if (!request || request.status !== 'approved') return <Navigate to="/" replace />;

  const isInvolved = currentUser.id === request.requesterId || currentUser.id === request.targetId;
  const requester = getUserById(request.requesterId);
  const target = getUserById(request.targetId);
  const connector = getUserById(request.connectorId);
  const contextPreRead = generateContextPreRead(requester, target);

  return (
    <div style={{ maxWidth: 640, margin: '0 auto' }}>
      <div className="outcome-header">
        <div className="outcome-icon">
          <svg width="28" height="28" fill="none" stroke="var(--sage)" strokeWidth="2" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"/>
          </svg>
        </div>
        <h1>Introduction Made!</h1>
        <p>{connector.name.split(' ')[0]} has connected {requester.name.split(' ')[0]} and {target.name.split(' ')[0]}</p>
      </div>

      <div className="intro-msg-box">
        <div className="label">Introduction Message</div>
        <p>{request.message}</p>
      </div>

      <div className="preread-grid">
        <div className="preread-card">
          <div className="preread-person">
            <div className="avatar avatar-you avatar-sm">
              {contextPreRead.person1.name.split(' ')[0][0]}{contextPreRead.person1.name.split(' ').pop()[0]}
            </div>
            <div className="preread-name">{contextPreRead.person1.name}</div>
          </div>
          <ul style={{ listStyle: 'none' }}>
            {contextPreRead.person1.bullets.map((bullet, i) => (
              <li key={i} className="preread-bullet">
                <div className="bullet-dot bullet-terracotta" />
                {bullet}
              </li>
            ))}
          </ul>
        </div>

        <div className="preread-card">
          <div className="preread-person">
            <div className="avatar avatar-target avatar-sm">
              {contextPreRead.person2.name.split(' ')[0][0]}{contextPreRead.person2.name.split(' ').pop()[0]}
            </div>
            <div className="preread-name">{contextPreRead.person2.name}</div>
          </div>
          <ul style={{ listStyle: 'none' }}>
            {contextPreRead.person2.bullets.map((bullet, i) => (
              <li key={i} className="preread-bullet">
                <div className="bullet-dot bullet-warm" />
                {bullet}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {isInvolved ? (
        <ContactExchange request={request} />
      ) : (
        <div className="contact-box">
          <h2>Introduction Sent</h2>
          <p>Both {requester.name.split(' ')[0]} and {target.name.split(' ')[0]} have been notified and can now connect directly.</p>
        </div>
      )}

      <div style={{ textAlign: 'center', marginTop: 20 }}>
        <Link to="/" className="back-link">← Back to Home</Link>
      </div>
    </div>
  );
}
