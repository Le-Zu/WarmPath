import { useUser } from '../context/UserContext';
import { userDetails, getDirectConnectionsCount } from '../data/mockData';

export default function Profile() {
  const { currentUser } = useUser();
  const details = userDetails[currentUser.id];
  const connectionCount = getDirectConnectionsCount(currentUser.id);
  const initials = `${currentUser.name.split(' ')[0][0]}${currentUser.name.split(' ').slice(-1)[0][0]}`;

  return (
    <div style={{ maxWidth: 640, margin: '0 auto' }}>
      <div className="profile-card">
        <div className="profile-header-row">
          <div className="profile-avatar">{initials}</div>
          <div>
            <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 24, fontWeight: 700 }}>
              {currentUser.name.replace(' (Jordan)', '')}
            </h1>
            <p style={{ fontSize: 14, color: 'var(--mid-gray)', marginTop: 3 }}>
              {currentUser.year} · {currentUser.major}
            </p>
            {details?.contactEmail && (
              <p style={{ fontSize: 13, color: 'var(--mid-gray)', marginTop: 4 }}>{details.contactEmail}</p>
            )}
          </div>
        </div>
      </div>

      <div className="profile-card">
        <div className="section-title">Your Network</div>
        <div className="network-stat">
          <div className="stat-circle">
            <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
            </svg>
          </div>
          <div>
            <div className="stat-num">{connectionCount}</div>
            <div className="stat-label">direct connections</div>
          </div>
        </div>
        <p style={{ fontSize: 13, color: 'var(--mid-gray)', marginTop: 14 }}>
          Your connections can help introduce you to people in their network.
        </p>
      </div>

      {details?.experiences?.length > 0 && (
        <div className="profile-card">
          <div className="section-title">Experiences</div>
          <ul className="exp-list">
            {details.experiences.map((exp, i) => (
              <li key={i} className="exp-item">
                <div className="exp-dot" />
                <span>{exp}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {details?.interests?.length > 0 && (
        <div className="profile-card">
          <div className="section-title">Interests</div>
          <div className="interest-tags">
            {details.interests.map((interest, i) => (
              <span key={i} className="interest-tag">{interest}</span>
            ))}
          </div>
        </div>
      )}

      <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--mid-gray)', marginTop: 20 }}>
        This is how others see you when you're suggested as a potential connection.
      </p>
    </div>
  );
}
