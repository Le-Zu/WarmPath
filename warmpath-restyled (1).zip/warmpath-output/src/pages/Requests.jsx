import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import {
  getPendingRequestsForConnector, getUserById,
  updateIntroRequestStatusWithTimestamp, introRequests, addNotification
} from '../data/mockData';

export default function Requests() {
  const { currentUser } = useUser();
  const navigate = useNavigate();
  const [requests, setRequests] = useState(() => getPendingRequestsForConnector(currentUser.id));
  const [editingId, setEditingId] = useState(null);
  const [editedMessage, setEditedMessage] = useState('');

  const handleApprove = (request) => {
    const target = getUserById(request.targetId);
    updateIntroRequestStatusWithTimestamp(request.id, 'approved');
    setRequests(requests.filter(r => r.id !== request.id));
    addNotification({
      userId: request.requesterId,
      type: 'intro_approved',
      message: `${currentUser.name.replace(' (Jordan)', '')} approved your intro request to ${target.name}!`,
      relatedRequestId: request.id
    });
    navigate(`/intro/${request.id}`);
  };

  const handleDecline = (request) => {
    const target = getUserById(request.targetId);
    updateIntroRequestStatusWithTimestamp(request.id, 'declined');
    setRequests(requests.filter(r => r.id !== request.id));
    addNotification({
      userId: request.requesterId,
      type: 'intro_declined',
      message: `Your intro request to ${target.name} wasn't approved this time.`,
      relatedRequestId: request.id
    });
  };

  const handleStartEdit = (request) => {
    setEditingId(request.id);
    setEditedMessage(request.message);
  };

  const handleSaveEdit = (request) => {
    const index = introRequests.findIndex(r => r.id === request.id);
    if (index !== -1) introRequests[index].message = editedMessage;
    setEditingId(null);
    handleApprove({ ...request, message: editedMessage });
  };

  if (requests.length === 0) {
    return (
      <div>
        <h1 className="page-title">Intro Requests</h1>
        <div className="empty-state">
          <div className="empty-icon">
            <svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
            </svg>
          </div>
          <h2>No pending requests</h2>
          <p>When someone in your network asks for an introduction through you, it'll appear here.</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="page-title">Intro Requests</h1>
      <p className="page-subtitle">People are asking you to make introductions. Review and decide.</p>

      <div>
        {requests.map(request => {
          const requester = getUserById(request.requesterId);
          const target = getUserById(request.targetId);
          const isEditing = editingId === request.id;

          return (
            <div key={request.id} className="card">
              {/* Path */}
              <div className="mini-path">
                <div className="mini-node">
                  <div className="avatar avatar-you avatar-sm">
                    {requester.name.split(' ')[0][0]}{requester.name.split(' ').pop()[0]}
                  </div>
                  <div className="mini-name">{requester.name.split(' ')[0]}</div>
                </div>
                <div className="mini-arrow">→</div>
                <div className="mini-node">
                  <div className="avatar avatar-conn avatar-sm">You</div>
                  <div className="mini-name">You</div>
                </div>
                <div className="mini-arrow">→</div>
                <div className="mini-node">
                  <div className="avatar avatar-target avatar-sm">
                    {target.name.split(' ')[0][0]}{target.name.split(' ').pop()[0]}
                  </div>
                  <div className="mini-name">{target.name.split(' ')[0]}</div>
                </div>
              </div>

              <p style={{ fontSize: 13, color: 'var(--mid-gray)', marginBottom: 12 }}>
                {requester.name} ({requester.year}, {requester.major}) wants to meet {target.name}
              </p>

              <div className="message-box" style={{ marginBottom: 16 }}>
                {isEditing ? (
                  <textarea
                    value={editedMessage}
                    onChange={(e) => setEditedMessage(e.target.value)}
                    rows={4}
                    style={{ background: 'var(--white)' }}
                  />
                ) : (
                  <p>{request.message}</p>
                )}
              </div>

              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                {isEditing ? (
                  <>
                    <button className="btn-ghost" onClick={() => setEditingId(null)}>Cancel</button>
                    <button className="btn-primary" style={{ padding: '9px 20px', fontSize: 14 }} onClick={() => handleSaveEdit(request)}>
                      Save & Approve
                    </button>
                  </>
                ) : (
                  <>
                    <button className="btn-danger-ghost" onClick={() => handleDecline(request)}>Decline</button>
                    <button className="btn-secondary" onClick={() => handleStartEdit(request)}>Edit & Approve</button>
                    <button className="btn-approve" onClick={() => handleApprove(request)}>Approve ✓</button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
