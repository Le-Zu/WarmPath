import { useState } from 'react';
import { generateIntroMessage, addIntroRequest, addNotification } from '../data/mockData';

export default function IntroRequestModal({ currentUser, connector, target, intent, onClose }) {
  const generatedMessage = generateIntroMessage(currentUser, connector.user, target.user, {
    description: intent.description || `looking for help with ${intent.category}`
  });
  const [message, setMessage] = useState(generatedMessage);
  const [status, setStatus] = useState('editing');

  const handleSend = () => {
    setStatus('sending');
    setTimeout(() => {
      const newRequest = addIntroRequest({
        intentId: null,
        requesterId: currentUser.id,
        connectorId: connector.user.id,
        targetId: target.user.id,
        message,
        status: 'pending'
      });
      addNotification({
        userId: connector.user.id,
        type: 'intro_request',
        message: `${currentUser.name.replace(' (Jordan)', '')} is asking you to introduce them to ${target.user.name}`,
        relatedRequestId: newRequest.id
      });
      setStatus('sent');
    }, 500);
  };

  if (status === 'sent') {
    return (
      <div className="modal-overlay">
        <div className="modal">
          <div className="modal-success">
            <div className="success-icon">
              <svg width="28" height="28" fill="none" stroke="var(--sage)" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"/>
              </svg>
            </div>
            <h2>Request Sent!</h2>
            <p>Your intro request has been sent to {connector.user.name.split(' ')[0]}. They'll review it and connect you with {target.user.name.split(' ')[0]} if they think it's a good fit.</p>
            <p style={{ fontSize: 13 }}>If they don't respond, the request will quietly expire. No awkwardness, no pressure.</p>
            <button className="btn-primary" style={{ marginTop: 20 }} onClick={onClose}>Done</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h2>Request Introduction</h2>
          <p>via {connector.user.name} → {target.user.name}</p>
        </div>
        <div className="modal-body">
          <label className="form-label">Your message to {connector.user.name.split(' ')[0]}</label>
          <p className="modal-sublabel">We've drafted a message for you. Feel free to edit it.</p>
          <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={5} />
          <div className="modal-note">
            <strong>Note:</strong> This message goes only to {connector.user.name.split(' ')[0]}. They'll decide whether to make the introduction. {target.user.name.split(' ')[0]} won't see your request unless they approve it.
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
          <button
            className="btn-primary"
            style={{ padding: '10px 22px' }}
            onClick={handleSend}
            disabled={status === 'sending' || !message.trim()}
          >
            {status === 'sending' ? 'Sending…' : 'Send Request'}
          </button>
        </div>
      </div>
    </div>
  );
}
