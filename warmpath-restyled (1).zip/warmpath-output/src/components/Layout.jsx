import { Link, useLocation } from 'react-router-dom';
import UserSwitcher from './UserSwitcher';
import NotificationBell from './NotificationBell';
import { useUser } from '../context/UserContext';
import { getPendingRequestsForConnector } from '../data/mockData';
import logo from '../assets/logo.js';

export default function Layout({ children }) {
  const location = useLocation();
  const { currentUser } = useUser();
  const pendingRequests = getPendingRequestsForConnector(currentUser.id);

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/my-requests', label: 'My Requests' },
    { path: '/requests', label: 'Inbox', badge: pendingRequests.length },
    { path: '/profile', label: 'Profile' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--ivory)' }}>
      <header className="header">
        <div className="header-inner">
          <Link to="/" className="logo">
            <img src={logo} alt="WarmPath" />
          </Link>
          <nav className="nav">
            {navItems.map(item => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-link ${location.pathname === item.path ? 'active' : ''}`}
              >
                {item.label}
                {item.badge > 0 && (
                  <span className="nav-badge">{item.badge}</span>
                )}
              </Link>
            ))}
            <NotificationBell />
            <UserSwitcher />
          </nav>
        </div>
      </header>
      <main className="main">
        {children}
      </main>
    </div>
  );
}
