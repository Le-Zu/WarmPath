import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import {
  getNotificationsForUser,
  getUnreadNotificationCount,
  markNotificationRead,
  markAllNotificationsRead
} from '../data/mockData';

const IconApproved = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"/>
  </svg>
);
const IconDeclined = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/>
  </svg>
);
const IconPeople = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
  </svg>
);
const IconMail = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
  </svg>
);

export default function NotificationBell() {
  const { currentUser } = useUser();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const dropdownRef = useRef(null);

  useEffect(() => {
    setNotifications(getNotificationsForUser(currentUser.id).slice(0, 10));
    setUnreadCount(getUnreadNotificationCount(currentUser.id));
  }, [currentUser.id, isOpen]);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNotificationClick = (notification) => {
    markNotificationRead(notification.id);
    setUnreadCount(prev => Math.max(0, prev - 1));
    setIsOpen(false);
    if (notification.type === 'intro_approved' && notification.relatedRequestId) {
      navigate(`/intro/${notification.relatedRequestId}`);
    } else if (notification.type === 'intro_request') {
      navigate('/requests');
    } else if (notification.type === 'contact_shared' && notification.relatedRequestId) {
      navigate(`/intro/${notification.relatedRequestId}`);
    } else {
      navigate('/my-requests');
    }
  };

  const handleMarkAllRead = () => {
    markAllNotificationsRead(currentUser.id);
    setUnreadCount(0);
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const formatTime = (timestamp) => {
    const diff = Date.now() - new Date(timestamp).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const getIcon = (type) => {
    switch (type) {
      case 'intro_approved': return <div className="notif-icon notif-icon-approved"><IconApproved /></div>;
      case 'intro_declined': return <div className="notif-icon notif-icon-declined"><IconDeclined /></div>;
      case 'intro_request':  return <div className="notif-icon notif-icon-request"><IconPeople /></div>;
      case 'contact_shared': return <div className="notif-icon notif-icon-contact"><IconMail /></div>;
      default: return <div className="notif-icon notif-icon-declined"><IconDeclined /></div>;
    }
  };

  return (
    <div style={{ position: 'relative' }} ref={dropdownRef}>
      <button className="bell-btn" onClick={() => setIsOpen(!isOpen)} aria-label="Notifications">
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.4-1.4A2 2 0 0118 14.2V11a6 6 0 00-4-5.66V5a2 2 0 10-4 0v.34A6 6 0 006 11v3.2c0 .53-.21 1.05-.6 1.43L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
        </svg>
        {unreadCount > 0 && <span className="bell-dot" />}
      </button>

      {isOpen && (
        <div className="bell-dropdown">
          <div className="bell-dropdown-header">
            <h3>Notifications</h3>
            {unreadCount > 0 && (
              <button className="btn-ghost" style={{ padding: '2px 0', fontSize: '13px', color: 'var(--terracotta)' }} onClick={handleMarkAllRead}>
                Mark all read
              </button>
            )}
          </div>
          <div className="notif-list">
            {notifications.length === 0 ? (
              <div style={{ padding: '20px', textAlign: 'center', fontSize: '14px', color: 'var(--mid-gray)' }}>
                No notifications yet
              </div>
            ) : (
              notifications.map(n => (
                <button key={n.id} className={`notif-item ${!n.read ? 'unread' : ''}`} onClick={() => handleNotificationClick(n)}>
                  {getIcon(n.type)}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="notif-text">{n.message}</div>
                    <div className="notif-time">{formatTime(n.createdAt)}</div>
                  </div>
                  {!n.read && <div className="notif-unread-dot" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
