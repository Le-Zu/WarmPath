import { useUser } from '../context/UserContext';

export default function UserSwitcher() {
  const { currentUser, setCurrentUser, allUsers } = useUser();

  return (
    <div className="user-switcher">
      <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <circle cx="12" cy="8" r="4"/>
        <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
      </svg>
      <select
        value={currentUser.id}
        onChange={(e) => {
          const user = allUsers.find(u => u.id === parseInt(e.target.value));
          if (user) setCurrentUser(user);
        }}
      >
        {allUsers.map(user => (
          <option key={user.id} value={user.id}>
            {user.name}
          </option>
        ))}
      </select>
    </div>
  );
}
