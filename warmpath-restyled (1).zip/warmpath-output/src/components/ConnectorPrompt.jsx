import { useState } from 'react';
import { useUser } from '../context/UserContext';
import { getNetworkIntents, categories, getConnectionsForUser, getUserById } from '../data/mockData';

export default function ConnectorPrompt() {
  const { currentUser } = useUser();
  const networkIntents = getNetworkIntents(currentUser.id);
  const [dismissed, setDismissed] = useState(false);
  const [showSuggestForm, setShowSuggestForm] = useState(false);

  if (networkIntents.length === 0 || dismissed) return null;

  const intent = networkIntents[0];
  const requester = getUserById(intent.userId);
  const category = categories.find(c => c.id === intent.category);

  if (showSuggestForm) {
    return (
      <ConnectorSuggestForm
        intent={intent}
        requester={requester}
        currentUser={currentUser}
        onClose={() => setShowSuggestForm(false)}
      />
    );
  }

  return (
    <div className="connector-prompt">
      <div className="prompt-emoji">{category?.icon}</div>
      <div className="prompt-content">
        <strong style={{ fontSize: '14px', color: 'var(--charcoal)' }}>Someone in your network needs help</strong>
        <p>
          <strong>{requester.name}</strong> is looking for help with <strong>{category?.label.toLowerCase()}</strong>
          {intent.description && `: "${intent.description}"`}
        </p>
        <div className="prompt-actions">
          <button className="btn-warm" onClick={() => setShowSuggestForm(true)}>I know someone who can help</button>
          <button className="btn-ghost" style={{ padding: '7px 0' }} onClick={() => setDismissed(true)}>Not right now</button>
        </div>
      </div>
      <button className="prompt-dismiss" onClick={() => setDismissed(true)}>×</button>
    </div>
  );
}

function ConnectorSuggestForm({ intent, requester, currentUser, onClose }) {
  const [person1, setPerson1] = useState('');
  const [reason, setReason] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const connections = getConnectionsForUser(currentUser.id);
  const knownPeople = connections.map(c => {
    const otherId = c.userA === currentUser.id ? c.userB : c.userA;
    return getUserById(otherId);
  }).filter(u => u && u.id !== requester.id);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="suggest-form-card" style={{ background: 'linear-gradient(135deg,#E8F4E1,#F0F8E8)', border: '1px solid #C8E6B8', textAlign: 'center' }}>
        <div style={{ width: 48, height: 48, borderRadius: '50%', background: '#C8E6B8', margin: '0 auto 12px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>✓</div>
        <p style={{ fontWeight: 600, marginBottom: 6 }}>Thanks for connecting people!</p>
        <p style={{ fontSize: 14, color: 'var(--mid-gray)', marginBottom: 12 }}>Your suggestion has been sent.</p>
        <button className="btn-ghost" style={{ color: 'var(--sage)' }} onClick={onClose}>Done</button>
      </div>
    );
  }

  return (
    <div className="suggest-form-card">
      <div className="suggest-form-header">
        <h3>Suggest a connection for {requester.name.split(' ')[0]}</h3>
        <button className="prompt-dismiss" onClick={onClose}>×</button>
      </div>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Who should they meet?</label>
          <select value={person1} onChange={(e) => setPerson1(e.target.value)} required>
            <option value="">Select someone you know...</option>
            {knownPeople.map(person => (
              <option key={person.id} value={person.id}>{person.name} ({person.major})</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label>Why should they meet?</label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="e.g., They both worked on similar research..."
            required
          />
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn-primary" style={{ padding: '9px 20px', fontSize: '14px' }}>Send Suggestion</button>
        </div>
      </form>
    </div>
  );
}
