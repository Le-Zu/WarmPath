export default function PathCard({ currentUser, connector, target, onRequestIntro }) {
  return (
    <div className="card">
      <div className="path-visual">
        <div className="path-node">
          <div className="avatar avatar-you avatar-md">You</div>
          <span className="node-name">You</span>
          <span className="node-sub">{currentUser.major}</span>
        </div>
        <div className="path-arrow">
          <div className="arrow-line" />
          <span className="arrow-label">{connector.context}</span>
        </div>
        <div className="path-node">
          <div className="avatar avatar-conn avatar-md">
            {connector.user.name.split(' ')[0][0]}{connector.user.name.split(' ').pop()[0]}
          </div>
          <span className="node-name">{connector.user.name.split(' ')[0]}</span>
          <span className="node-sub">{connector.user.major}</span>
        </div>
        <div className="path-arrow">
          <div className="arrow-line" />
          <span className="arrow-label">{target.context}</span>
        </div>
        <div className="path-node">
          <div className="avatar avatar-target avatar-md">
            {target.user.name.split(' ')[0][0]}{target.user.name.split(' ').pop()[0]}
          </div>
          <span className="node-name">{target.user.name.split(' ')[0]}</span>
          <span className="node-sub">{target.user.major}</span>
        </div>
      </div>

      <div className="warmth-row">
        <div className="warmth-chip">
          <div className="dot dot-sage" />
          You & {connector.user.name.split(' ')[0]}: {connector.warmth}
        </div>
        <div className="warmth-chip">
          <div className="dot dot-warm" />
          {connector.user.name.split(' ')[0]} & {target.user.name.split(' ')[0]}: {target.warmth}
        </div>
      </div>

      <div className="card-footer">
        <div className="availability">
          <div className={`dot ${connector.openToIntros ? 'dot-open' : 'dot-closed'}`} />
          {connector.openToIntros ? 'Open to making intros' : 'Not available for intros'}
        </div>
        <button
          className="btn-primary"
          style={{ padding: '9px 20px', fontSize: '13px' }}
          onClick={onRequestIntro}
          disabled={!connector.openToIntros}
        >
          Request Intro
        </button>
      </div>
    </div>
  );
}
