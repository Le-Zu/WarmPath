import { useState } from 'react';
import { useUser } from '../context/UserContext';
import { userDetails, getUserById, markContactShared, addNotification } from '../data/mockData';

export default function ContactExchange({ request }) {
  const { currentUser } = useUser();
  const [showContacts, setShowContacts] = useState(request.contactShared);

  const requester = getUserById(request.requesterId);
  const target = getUserById(request.targetId);
  const requesterDetails = userDetails[request.requesterId];
  const targetDetails = userDetails[request.targetId];

  const isRequester = currentUser.id === request.requesterId;
  const isTarget = currentUser.id === request.targetId;
  const otherPerson = isRequester ? target : requester;
  const otherPersonDetails = isRequester ? targetDetails : requesterDetails;

  const handleShareContact = () => {
    markContactShared(request.id);
    setShowContacts(true);
    addNotification({
      userId: otherPerson.id,
      type: 'contact_shared',
      message: `${currentUser.name.replace(' (Jordan)', '')} shared their contact info with you`,
      relatedRequestId: request.id
    });
  };

  if (!isRequester && !isTarget) return null;

  return (
    <div className="contact-box">
      <h2>Connect with {otherPerson.name.split(' ')[0]}</h2>
      {!showContacts ? (
        <>
          <p>Ready to connect? Share your contact info to get in touch directly.</p>
          <button className="btn-sage" onClick={handleShareContact}>
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
            Share Contact Info
          </button>
        </>
      ) : (
        <>
          <p style={{ marginBottom: 12 }}>Contact info shared! 🎊</p>
          <div className="contact-cards">
            <div className="contact-info-card">
              <div className="avatar avatar-you avatar-sm">
                {currentUser.name.split(' ')[0][0]}{currentUser.name.split(' ').slice(-1)[0][0]}
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>Your contact info</div>
                <div style={{ fontSize: 13, color: 'var(--mid-gray)' }}>{userDetails[currentUser.id]?.contactEmail}</div>
              </div>
            </div>
            <div className="contact-info-card">
              <div className="avatar avatar-target avatar-sm">
                {otherPerson.name.split(' ')[0][0]}{otherPerson.name.split(' ').slice(-1)[0][0]}
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{otherPerson.name}'s contact info</div>
                <div style={{ fontSize: 13, color: 'var(--mid-gray)' }}>{otherPersonDetails?.contactEmail}</div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
